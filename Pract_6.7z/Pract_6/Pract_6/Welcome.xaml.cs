﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Pract_6
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Welcome :ContentPage
    {
        public string Login;
        public string Password;
        public Welcome ()
        {
            InitializeComponent();
        }

        private void signin_Clicked (object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(login.Text) || string.IsNullOrEmpty(password.Text))
            {
                DisplayAlert("Ошибка", "Введите все необходимые данные", "Ок");
            } else
            {
                Login = login.Text;
                Password = password.Text;
                Navigation.PushAsync(new Elementsss(Login, Password));
            }
        }
    }
}