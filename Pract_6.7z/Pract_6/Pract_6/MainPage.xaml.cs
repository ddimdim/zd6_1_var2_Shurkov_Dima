﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Pract_6
{
    public partial class MainPage : ContentPage
    {
        public MainPage (string login, string password)
        {
            InitializeComponent();
            
        }
    }
}
