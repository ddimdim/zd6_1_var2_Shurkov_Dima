﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Pract_6
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Elementsss : CarouselPage
    {
        public double max = 0;
        public Elementsss (string Login, string Password)
        {
            InitializeComponent();
            login.Text = $"Логин: {Login}";
            password.Text = $"Пароль: {Password}";
        }

        private void swich1_Toggled(object sender, ToggledEventArgs e)
        {
            if (switch1.IsToggled == true)
            {
                OnOff1.Text = "ON";
                switch2.IsToggled = false;
            }
            else
            {
                OnOff1.Text = "OFF";
                switch2.IsToggled = true;
            }
        }

        private void swich2_Toggled(object sender, ToggledEventArgs e)
        {
            if (switch2.IsToggled == true)
            {
                OnOff2.Text = "ON";
                switch1.IsToggled = false;
            }
            else
            {
                OnOff2.Text = "OFF";
                switch1.IsToggled = true;
            }
        }

        private void swich3_Toggled(object sender, ToggledEventArgs e)
        {
            if (switch3.IsToggled == true)
            {
                OnOff3.Text = "✓";
                switch4.IsToggled = false;
            }
            else
            {
                OnOff3.Text = "✕";
                switch4.IsToggled = true;
            }
        }

        private void swich4_Toggled(object sender, ToggledEventArgs e)
        {
            if (switch4.IsToggled == true)
            {
                OnOff4.Text = "✓";
                switch3.IsToggled = false;
            }
            else
            {
                OnOff4.Text = "✕";
                switch3.IsToggled = true;
            }
                
        }

        private void static1_Clicked(object sender, EventArgs e)
        {
            if (max < slider.Value)
            {
                max = slider.Value;
                MaxSlider.Text = $"Максимальное значение 1-ого Sliderа: {max}";
            }
        }

        private void switch5_Toggled(object sender, ToggledEventArgs e)
        {
            if (switch5.IsToggled == true)
            {
                switch6.IsToggled = false;
            }
            else
            {
                switch6.IsToggled = true;
            }
        }

        private void switch6_Toggled(object sender, ToggledEventArgs e)
        {
            if (switch6.IsToggled == true)
            {
                switch5.IsToggled = false;
            }
            else
            {
                switch5.IsToggled = true;
            }
        }

        
        private void radio1_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            if (radio1.IsChecked == true)
            {
                switch1.IsEnabled = false;
                switch2.IsEnabled = false;
                switch3.IsEnabled = false;
                switch4.IsEnabled = false;
                switch5.IsEnabled = false;
                switch6.IsEnabled = false;
            }
            else
            {
                switch1.IsEnabled = true;
                switch2.IsEnabled = true;
                switch3.IsEnabled = true;
                switch4.IsEnabled = true;
                switch5.IsEnabled = true;
                switch6.IsEnabled = true;
            }
        }
        private void radio2_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            if (radio2.IsChecked == true)
            {
                switch1.IsEnabled = true;
                switch2.IsEnabled = true;
                switch3.IsEnabled = true;
                switch4.IsEnabled = true;
                switch5.IsEnabled = true;
                switch6.IsEnabled = true;
                
            }
            else
            {
                switch1.IsEnabled = false;
                switch2.IsEnabled = false;
                switch3.IsEnabled = false;
                switch4.IsEnabled = false;
                switch5.IsEnabled = false;
                switch6.IsEnabled = false;
            }
        }
    }
}